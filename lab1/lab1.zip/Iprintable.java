public interface Iprintable 
{
    public abstract void print();
    
    public abstract void flush();
    
    public abstract String get_field();
    
    public abstract void set_field(String arg);
    

}
